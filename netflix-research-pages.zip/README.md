# 奈飞｜注意力的复利

原创中文奈飞研究网站，基于 Netflix 2026 Q3 股东信。

## 功能

- 十页幻灯片与长文阅读模式
- 财务趋势、广告业务、现金流及风险分析
- 可调整自由现金流和估值倍数的情景工具
- 响应式布局、键盘翻页、全屏阅读

## 本地运行

无需安装依赖。直接打开 `dist/index.html`，或运行：

```sh
python3 -m http.server 8000 --directory dist
```

浏览器访问 http://localhost:8000 。

## 部署

将 `dist` 目录作为静态网站发布目录。财务数据为固定快照，不自动更新。

## 数据来源

https://ir.netflix.net/files/doc_financials/2026/q3/FINAL-Q3-26-Shareholder-Letter.pdf

研究日期：2026-11-13。估值为假设演示，仅供学习研究。

## GitHub Pages 发布

发布目录已经准备在 `docs/`。将本项目上传到 GitHub 仓库后：

1. 打开仓库 Settings → Pages。
2. Source 选择 Deploy from a branch。
3. Branch 选择 main，目录选择 /docs，点击 Save。
4. 等待 GitHub Pages 部署完成，在 Pages 页面打开网站链接。

`docs/index.html` 是完整独立页面，无外部资源依赖。更新网页时请同步 `dist/index.html` 与 `docs/index.html`。
